package com.example.quotes

import android.content.Context

object AppPrefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("app_settings", Context.MODE_PRIVATE)

    fun language(ctx: Context): String = p(ctx).getString("lang", "system") ?: "system"

    fun setLanguage(ctx: Context, value: String) {
        p(ctx).edit().putString("lang", value).apply()
    }

    fun notifyEnabled(ctx: Context): Boolean = p(ctx).getBoolean("notify_enabled", false)

    fun setNotifyEnabled(ctx: Context, value: Boolean) {
        p(ctx).edit().putBoolean("notify_enabled", value).apply()
    }

    fun notifyHour(ctx: Context): Int = p(ctx).getInt("notify_hour", 9)

    fun notifyMinute(ctx: Context): Int = p(ctx).getInt("notify_minute", 0)

    fun setNotifyTime(ctx: Context, hour: Int, minute: Int) {
        p(ctx).edit().putInt("notify_hour", hour).putInt("notify_minute", minute).apply()
    }
}
