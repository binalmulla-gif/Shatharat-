package com.example.quotes

import android.content.Intent

object ShareUtil {
    // The quote in quotation marks, and only the author's name under it
    fun text(q: Quote): String {
        val quote = "“" + q.text + "”"
        return if (q.author.isNotEmpty()) quote + "\n— " + q.author else quote
    }

    fun chooser(q: Quote): Intent {
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(Intent.EXTRA_TEXT, text(q))
        val chooser = Intent.createChooser(send, null)
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return chooser
    }
}
