package com.example.quotes

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.format.DateFormat
import android.view.View
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class SettingsActivity : BaseActivity() {

    private lateinit var notifySwitch: Switch
    private lateinit var notifyTime: TextView
    private lateinit var notifyTest: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // ---- language
        val group = findViewById<RadioGroup>(R.id.lang_group)
        when (AppPrefs.language(this)) {
            "ar" -> group.check(R.id.lang_ar)
            "en" -> group.check(R.id.lang_en)
            else -> group.check(R.id.lang_system)
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            val value = when (checkedId) {
                R.id.lang_ar -> "ar"
                R.id.lang_en -> "en"
                else -> "system"
            }
            if (value != AppPrefs.language(this)) {
                AppPrefs.setLanguage(this, value)
                recreate()
            }
        }

        // ---- notifications
        notifySwitch = findViewById(R.id.notify_switch)
        notifyTime = findViewById(R.id.notify_time)
        notifyTest = findViewById(R.id.notify_test)
        notifySwitch.isChecked = AppPrefs.notifyEnabled(this)
        updateNotifyUi()

        notifySwitch.setOnClickListener {
            if (notifySwitch.isChecked) {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
                } else {
                    enableNotifications()
                }
            } else {
                AppPrefs.setNotifyEnabled(this, false)
                Notifier.cancelDaily(this)
                updateNotifyUi()
            }
        }

        notifyTime.setOnClickListener {
            TimePickerDialog(
                this,
                { _, hour, minute ->
                    AppPrefs.setNotifyTime(this, hour, minute)
                    Notifier.scheduleDaily(this)
                    updateNotifyUi()
                },
                AppPrefs.notifyHour(this),
                AppPrefs.notifyMinute(this),
                DateFormat.is24HourFormat(this)
            ).show()
        }

        notifyTest.setOnClickListener {
            if (!Notifier.show(this)) {
                Toast.makeText(this, R.string.notif_cannot, Toast.LENGTH_LONG).show()
            }
        }

        // ---- battery settings (helps the widget and notification run on time)
        findViewById<TextView>(R.id.battery_button).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                i.data = Uri.parse("package:" + packageName)
                startActivity(i)
            }
        }

        // ---- backup
        findViewById<TextView>(R.id.backup_export).setOnClickListener {
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "application/json"
            val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            i.putExtra(Intent.EXTRA_TITLE, "quotes-backup-$day.json")
            startActivityForResult(i, REQ_EXPORT)
        }
        findViewById<TextView>(R.id.backup_import).setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            startActivityForResult(i, REQ_IMPORT)
        }
    }

    private fun enableNotifications() {
        AppPrefs.setNotifyEnabled(this, true)
        Notifier.scheduleDaily(this)
        updateNotifyUi()
    }

    private fun updateNotifyUi() {
        val enabled = AppPrefs.notifyEnabled(this)
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, AppPrefs.notifyHour(this))
        cal.set(Calendar.MINUTE, AppPrefs.notifyMinute(this))
        val timeText = DateFormat.getTimeFormat(this).format(cal.time)
        notifyTime.text = getString(R.string.notif_time_fmt, timeText)
        notifyTime.visibility = if (enabled) View.VISIBLE else View.GONE
        notifyTest.visibility = if (enabled) View.VISIBLE else View.GONE
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableNotifications()
            } else {
                notifySwitch.isChecked = false
                Toast.makeText(this, R.string.notif_denied, Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == REQ_EXPORT) {
            val ok = BackupHelper.exportTo(this, uri)
            Toast.makeText(
                this,
                if (ok) R.string.backup_exported else R.string.backup_failed,
                Toast.LENGTH_SHORT
            ).show()
        } else if (requestCode == REQ_IMPORT) {
            val added = BackupHelper.importFrom(this, uri)
            if (added >= 0) {
                QuoteWidgetProvider.refreshAll(this)
                Toast.makeText(
                    this,
                    getString(R.string.backup_imported_fmt, added),
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(this, R.string.backup_failed, Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        private const val REQ_NOTIF = 11
        private const val REQ_EXPORT = 12
        private const val REQ_IMPORT = 13
    }
}
