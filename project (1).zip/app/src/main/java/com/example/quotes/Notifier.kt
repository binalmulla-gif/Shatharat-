package com.example.quotes

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import java.util.Calendar

object Notifier {
    private const val CHANNEL_ID = "daily_quote"
    private const val NOTIFICATION_ID = 1001
    private const val REQUEST_DAILY = 7002
    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    private fun dailyIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, WidgetEventReceiver::class.java)
        i.action = WidgetEventReceiver.ACTION_DAILY
        return PendingIntent.getBroadcast(ctx, REQUEST_DAILY, i, FLAGS)
    }

    // Sets the next daily alarm at the time chosen in the settings
    fun scheduleDaily(context: Context) {
        val ctx = context.applicationContext
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = dailyIntent(ctx)
        am.cancel(pi)
        if (!AppPrefs.notifyEnabled(ctx)) return
        val now = Calendar.getInstance()
        val next = Calendar.getInstance()
        next.set(Calendar.HOUR_OF_DAY, AppPrefs.notifyHour(ctx))
        next.set(Calendar.MINUTE, AppPrefs.notifyMinute(ctx))
        next.set(Calendar.SECOND, 0)
        next.set(Calendar.MILLISECOND, 0)
        if (!next.after(now)) next.add(Calendar.DAY_OF_YEAR, 1)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
    }

    fun cancelDaily(context: Context) {
        val ctx = context.applicationContext
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(dailyIntent(ctx))
    }

    // Posts a notification with a random quote. Returns false if nothing could be posted.
    fun show(context: Context): Boolean {
        val ctx = context.applicationContext
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return false
        }
        val q = QuoteStore.randomForWidget(ctx, -1L) ?: return false
        val lc = LocaleHelper.wrap(ctx)
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                lc.getString(R.string.notif_channel),
                NotificationManager.IMPORTANCE_DEFAULT
            )
            nm.createNotificationChannel(channel)
        }

        val openPi = PendingIntent.getActivity(
            ctx, 7004, Intent(ctx, MainActivity::class.java), FLAGS
        )
        val sharePi = PendingIntent.getActivity(ctx, 7003, ShareUtil.chooser(q), FLAGS)

        val builder: Notification.Builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(ctx, CHANNEL_ID)
        } else {
            Notification.Builder(ctx)
        }
        val title = if (q.author.isNotEmpty()) q.author else lc.getString(R.string.app_name)
        builder.setSmallIcon(R.drawable.ic_stat_quote)
        builder.setContentTitle(title)
        builder.setContentText(q.text)
        builder.setStyle(Notification.BigTextStyle().bigText(q.text))
        builder.setContentIntent(openPi)
        builder.setAutoCancel(true)
        builder.addAction(
            Notification.Action.Builder(
                Icon.createWithResource(ctx, R.drawable.ic_share),
                lc.getString(R.string.share),
                sharePi
            ).build()
        )
        nm.notify(NOTIFICATION_ID, builder.build())
        return true
    }
}
