package com.example.quotes

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// An hourly alarm that rotates the widget quote. It does not wake the phone: if the phone is asleep
// when the hour comes, it fires as soon as the phone wakes up (for example when you unlock it).
object UpdateScheduler {
    private const val HOUR_MS = 60L * 60L * 1000L
    private const val REQUEST_TICK = 7001
    const val PREFS = "widget_state"
    private const val KEY_NEXT_TICK = "next_tick"

    private fun tickIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, WidgetEventReceiver::class.java)
        i.action = WidgetEventReceiver.ACTION_TICK
        return PendingIntent.getBroadcast(
            ctx,
            REQUEST_TICK,
            i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    // force = false keeps an alarm that is still pending; force = true always sets a new one
    fun scheduleTick(context: Context, force: Boolean) {
        val ctx = context.applicationContext
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (!force && sp.getLong(KEY_NEXT_TICK, 0L) > now) return
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val at = now + HOUR_MS
        am.setAndAllowWhileIdle(AlarmManager.RTC, at, tickIntent(ctx))
        sp.edit().putLong(KEY_NEXT_TICK, at).apply()
    }

    fun cancelTick(context: Context) {
        val ctx = context.applicationContext
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(tickIntent(ctx))
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_NEXT_TICK).apply()
    }
}

class WidgetEventReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == ACTION_TICK) {
            QuoteWidgetProvider.refreshIfDue(context)
            if (QuoteWidgetProvider.hasWidgets(context)) {
                UpdateScheduler.scheduleTick(context, true)
            }
        } else if (action == ACTION_DAILY) {
            if (AppPrefs.notifyEnabled(context)) {
                Notifier.show(context)
                Notifier.scheduleDaily(context)
            }
        } else if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            if (QuoteWidgetProvider.hasWidgets(context)) {
                QuoteWidgetProvider.refreshIfDue(context)
                UpdateScheduler.scheduleTick(context, true)
            }
            if (AppPrefs.notifyEnabled(context)) {
                Notifier.scheduleDaily(context)
            }
        }
    }

    companion object {
        const val ACTION_TICK = "com.example.quotes.TICK"
        const val ACTION_DAILY = "com.example.quotes.DAILY"
    }
}
