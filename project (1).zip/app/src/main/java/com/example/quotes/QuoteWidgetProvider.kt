package com.example.quotes

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.view.View
import android.widget.RemoteViews

class QuoteWidgetProvider : AppWidgetProvider() {

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        UpdateScheduler.scheduleTick(context, true)
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        UpdateScheduler.cancelTick(context)
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        // makes sure the hourly alarm exists (it repairs itself if it was lost)
        UpdateScheduler.scheduleTick(context, false)
        val due = isDue(context)
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, buildViews(context, appWidgetManager, id, due))
        }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        appWidgetManager.updateAppWidget(
            appWidgetId,
            buildViews(context, appWidgetManager, appWidgetId, false)
        )
    }

    companion object {
        private const val KEY_LAST_CHANGE = "last_change"
        // a little less than an hour, so an update that arrives slightly early still counts
        private const val DUE_MS = 55L * 60L * 1000L

        private fun state(context: Context) =
            context.getSharedPreferences(UpdateScheduler.PREFS, Context.MODE_PRIVATE)

        private fun isDue(context: Context): Boolean {
            val last = state(context).getLong(KEY_LAST_CHANGE, 0L)
            return System.currentTimeMillis() - last >= DUE_MS
        }

        fun hasWidgets(context: Context): Boolean {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, QuoteWidgetProvider::class.java)
            )
            return ids.isNotEmpty()
        }

        // Changes the quote only if about an hour has passed since the last change
        fun refreshIfDue(context: Context) {
            if (isDue(context)) refreshAll(context, true)
        }

        // forceNew = true picks a new random quote; false keeps the one currently shown
        fun refreshAll(context: Context, forceNew: Boolean = false) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, QuoteWidgetProvider::class.java)
            )
            for (id in ids) {
                manager.updateAppWidget(id, buildViews(context, manager, id, forceNew))
            }
        }

        private fun pickQuote(context: Context, widgetId: Int, forceNew: Boolean): Quote? {
            val sp = state(context)
            val currentId = sp.getLong("w_$widgetId", -1L)
            var q: Quote? = null
            if (!forceNew && currentId != -1L) {
                val c = QuoteStore.get(context, currentId)
                if (c != null && c.showInWidget) q = c
            }
            val editor = sp.edit()
            if (q == null) {
                q = QuoteStore.randomForWidget(context, currentId)
                editor.putLong(KEY_LAST_CHANGE, System.currentTimeMillis())
            }
            editor.putLong("w_$widgetId", q?.id ?: -1L)
            editor.apply()
            return q
        }

        private fun buildMeta(q: Quote): CharSequence {
            val sb = SpannableStringBuilder()
            if (q.author.isNotEmpty()) {
                sb.append(q.author)
                sb.setSpan(
                    StyleSpan(Typeface.BOLD),
                    0,
                    sb.length,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
            if (q.source.isNotEmpty()) {
                if (sb.isNotEmpty()) sb.append(" — ")
                sb.append(q.source)
            }
            return sb
        }

        private fun buildViews(
            context: Context,
            manager: AppWidgetManager,
            widgetId: Int,
            forceNew: Boolean
        ): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_quote)
            val lc = LocaleHelper.wrap(context)

            // Fit the number of quote lines to the widget height so the author line is never cut off
            val options = manager.getAppWidgetOptions(widgetId)
            var heightDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
            if (heightDp <= 0) heightDp = 180
            val lines = ((heightDp - 60) / 24).coerceIn(2, 12)
            views.setInt(R.id.w_text, "setMaxLines", lines)

            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

            val q = pickQuote(context, widgetId, forceNew)
            if (q == null) {
                val message = if (QuoteStore.count(context) == 0L) {
                    R.string.widget_empty
                } else {
                    R.string.widget_none_visible
                }
                views.setTextViewText(R.id.w_text, lc.getString(message))
                views.setViewVisibility(R.id.w_meta, View.GONE)
                views.setViewVisibility(R.id.w_share, View.GONE)
            } else {
                views.setTextViewText(R.id.w_text, q.text)
                val meta = buildMeta(q)
                if (meta.isEmpty()) {
                    views.setViewVisibility(R.id.w_meta, View.GONE)
                } else {
                    views.setViewVisibility(R.id.w_meta, View.VISIBLE)
                    views.setTextViewText(R.id.w_meta, meta)
                }
                views.setViewVisibility(R.id.w_share, View.VISIBLE)
                views.setOnClickPendingIntent(
                    R.id.w_share,
                    PendingIntent.getActivity(context, 1000 + widgetId, ShareUtil.chooser(q), flags)
                )
            }

            val openIntent = Intent(context, MainActivity::class.java)
            views.setOnClickPendingIntent(
                R.id.w_root,
                PendingIntent.getActivity(context, 1, openIntent, flags)
            )
            return views
        }
    }
}
