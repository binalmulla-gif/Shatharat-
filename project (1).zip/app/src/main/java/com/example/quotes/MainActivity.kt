package com.example.quotes

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.StyleSpan
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.app.AlertDialog
import java.text.DateFormat
import java.util.Date

class MainActivity : BaseActivity() {

    private lateinit var listView: ListView
    private lateinit var countView: TextView
    private lateinit var emptyView: TextView
    private lateinit var searchField: EditText
    private lateinit var filterBar: View
    private lateinit var filterLabel: TextView
    private lateinit var adapter: QuoteAdapter

    private var allQuotes: List<Quote> = emptyList()
    private var quotes: List<Quote> = emptyList()
    private var filterType: String? = null
    private var filterValue: String = ""
    private var query: String = ""
    private var shownLanguage: String = "system"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        shownLanguage = AppPrefs.language(this)
        setContentView(R.layout.activity_main)

        listView = findViewById(R.id.list)
        countView = findViewById(R.id.count)
        emptyView = findViewById(R.id.empty)
        searchField = findViewById(R.id.search_field)
        filterBar = findViewById(R.id.filter_bar)
        filterLabel = findViewById(R.id.filter_label)

        adapter = QuoteAdapter()
        listView.adapter = adapter
        listView.emptyView = emptyView

        findViewById<TextView>(R.id.add_button).setOnClickListener {
            startActivity(Intent(this, EditQuoteActivity::class.java))
        }
        findViewById<TextView>(R.id.settings_button).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<TextView>(R.id.browse_button).setOnClickListener {
            startActivityForResult(Intent(this, BrowseActivity::class.java), REQ_BROWSE)
        }
        findViewById<TextView>(R.id.clear_filter).setOnClickListener {
            filterType = null
            filterValue = ""
            applyFilters()
        }

        searchField.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }

            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                applyFilters()
            }
        })

        listView.setOnItemClickListener { _, _, position, _ ->
            val i = Intent(this, EditQuoteActivity::class.java)
            i.putExtra(EditQuoteActivity.EXTRA_ID, quotes[position].id)
            startActivity(i)
        }
        listView.setOnItemLongClickListener { _, _, position, _ ->
            confirmDelete(quotes[position])
            true
        }
    }

    override fun onResume() {
        super.onResume()
        if (AppPrefs.language(this) != shownLanguage) {
            recreate()
            return
        }
        // keeps the widget and the daily notification on schedule
        if (QuoteWidgetProvider.hasWidgets(this)) {
            QuoteWidgetProvider.refreshIfDue(this)
            UpdateScheduler.scheduleTick(this, false)
        }
        if (AppPrefs.notifyEnabled(this)) Notifier.scheduleDaily(this)
        reload()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_BROWSE && resultCode == RESULT_OK && data != null) {
            filterType = data.getStringExtra(BrowseActivity.EXTRA_TYPE)
            filterValue = data.getStringExtra(BrowseActivity.EXTRA_VALUE) ?: ""
            applyFilters()
        }
    }

    private fun reload() {
        allQuotes = QuoteStore.all(this)
        applyFilters()
    }

    private fun applyFilters() {
        val q = TextUtil.normalize(query)
        quotes = allQuotes.filter { item ->
            val matchesFilter = when (filterType) {
                "author" -> item.author == filterValue
                "source" -> item.source == filterValue
                else -> true
            }
            val matchesQuery = q.isEmpty() ||
                TextUtil.normalize(item.text).contains(q) ||
                TextUtil.normalize(item.author).contains(q) ||
                TextUtil.normalize(item.source).contains(q) ||
                TextUtil.normalize(item.note).contains(q)
            matchesFilter && matchesQuery
        }
        countView.text = getString(R.string.count_fmt, quotes.size)
        emptyView.setText(if (allQuotes.isEmpty()) R.string.empty_list else R.string.no_results)
        if (filterType == null) {
            filterBar.visibility = View.GONE
        } else {
            filterBar.visibility = View.VISIBLE
            val labelRes =
                if (filterType == "author") R.string.filter_author_fmt else R.string.filter_source_fmt
            filterLabel.text = getString(labelRes, filterValue)
        }
        adapter.notifyDataSetChanged()
    }

    private fun confirmDelete(q: Quote) {
        AlertDialog.Builder(this)
            .setMessage(R.string.delete_confirm)
            .setPositiveButton(R.string.delete) { _, _ ->
                QuoteStore.delete(this, q.id)
                QuoteWidgetProvider.refreshAll(this)
                reload()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private inner class QuoteAdapter : BaseAdapter() {
        private val dateFormat = DateFormat.getDateInstance(DateFormat.MEDIUM)

        override fun getCount(): Int = quotes.size

        override fun getItem(position: Int): Any = quotes[position]

        override fun getItemId(position: Int): Long = quotes[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_quote, parent, false)
            val q = quotes[position]
            v.findViewById<TextView>(R.id.q_text).text = q.text

            val meta = SpannableStringBuilder()
            if (q.author.isNotEmpty()) {
                meta.append(q.author)
                meta.setSpan(
                    StyleSpan(Typeface.BOLD),
                    0,
                    meta.length,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
            if (q.source.isNotEmpty()) {
                if (meta.isNotEmpty()) meta.append(" — ")
                meta.append(q.source)
            }
            val metaView = v.findViewById<TextView>(R.id.q_meta)
            metaView.visibility = if (meta.isEmpty()) View.GONE else View.VISIBLE
            metaView.text = meta

            var dateText = dateFormat.format(Date(q.createdAt))
            if (q.note.isNotEmpty()) dateText += " · " + getString(R.string.has_note)
            if (!q.showInWidget) dateText += " · " + getString(R.string.hidden_from_widget)
            v.findViewById<TextView>(R.id.q_date).text = dateText
            return v
        }
    }

    companion object {
        private const val REQ_BROWSE = 1
    }
}
