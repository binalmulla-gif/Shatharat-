package com.example.quotes

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView

class BrowseActivity : BaseActivity() {

    private var showAuthors = true
    private var items: List<Pair<String, Int>> = emptyList()
    private lateinit var tabAuthors: TextView
    private lateinit var tabBooks: TextView
    private lateinit var emptyView: TextView
    private lateinit var adapter: NamesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browse)

        tabAuthors = findViewById(R.id.tab_authors)
        tabBooks = findViewById(R.id.tab_books)
        emptyView = findViewById(R.id.browse_empty)
        val listView = findViewById<ListView>(R.id.browse_list)

        adapter = NamesAdapter()
        listView.adapter = adapter
        listView.emptyView = emptyView

        tabAuthors.setOnClickListener {
            showAuthors = true
            load()
        }
        tabBooks.setOnClickListener {
            showAuthors = false
            load()
        }
        listView.setOnItemClickListener { _, _, position, _ ->
            val result = Intent()
            result.putExtra(EXTRA_TYPE, if (showAuthors) "author" else "source")
            result.putExtra(EXTRA_VALUE, items[position].first)
            setResult(RESULT_OK, result)
            finish()
        }
        load()
    }

    private fun load() {
        items = if (showAuthors) QuoteStore.authorCounts(this) else QuoteStore.sourceCounts(this)
        styleTab(tabAuthors, showAuthors)
        styleTab(tabBooks, !showAuthors)
        adapter.notifyDataSetChanged()
    }

    private fun styleTab(tab: TextView, selected: Boolean) {
        tab.setTextColor(Color.parseColor(if (selected) "#1C1C1C" else "#9A9A9A"))
        tab.setTypeface(null, if (selected) Typeface.BOLD else Typeface.NORMAL)
    }

    private inner class NamesAdapter : BaseAdapter() {
        override fun getCount(): Int = items.size

        override fun getItem(position: Int): Any = items[position]

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_browse, parent, false)
            v.findViewById<TextView>(R.id.b_name).text = items[position].first
            v.findViewById<TextView>(R.id.b_count).text = items[position].second.toString()
            return v
        }
    }

    companion object {
        const val EXTRA_TYPE = "filter_type"
        const val EXTRA_VALUE = "filter_value"
    }
}
