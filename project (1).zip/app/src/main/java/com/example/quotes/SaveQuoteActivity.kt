package com.example.quotes

import android.content.Intent
import android.os.Bundle
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class SaveQuoteActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val quoteText = extractText()
        if (quoteText.isBlank()) {
            finish()
            return
        }

        setContentView(R.layout.dialog_save)

        val textView = findViewById<TextView>(R.id.d_text)
        val authorField = findViewById<AutoCompleteTextView>(R.id.d_author)
        val sourceField = findViewById<AutoCompleteTextView>(R.id.d_source)
        val saveButton = findViewById<Button>(R.id.d_save)
        val cancelButton = findViewById<Button>(R.id.d_cancel)

        authorField.setAdapter(SuggestAdapter(this, QuoteStore.authors(this)))
        sourceField.setAdapter(SuggestAdapter(this, QuoteStore.sources(this)))

        textView.text = quoteText
        authorField.setText(QuoteStore.lastAuthor(this), false)
        sourceField.setText(QuoteStore.lastSource(this), false)

        saveButton.setOnClickListener {
            QuoteStore.add(
                this,
                quoteText,
                authorField.text.toString().trim(),
                sourceField.text.toString().trim()
            )
            QuoteWidgetProvider.refreshAll(this)
            Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show()
            finish()
        }
        cancelButton.setOnClickListener { finish() }
    }

    private fun extractText(): String {
        val i = intent ?: return ""
        val t: CharSequence? = when (i.action) {
            Intent.ACTION_PROCESS_TEXT -> i.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)
            Intent.ACTION_SEND -> i.getCharSequenceExtra(Intent.EXTRA_TEXT)
            else -> null
        }
        return t?.toString()?.trim() ?: ""
    }
}
