package com.example.quotes

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

object LocaleHelper {
    // Returns a context that uses the language chosen inside the app (or the phone language)
    fun wrap(base: Context): Context {
        val lang = AppPrefs.language(base)
        val current = base.resources.configuration
        if (lang != "ar" && lang != "en") {
            Locale.setDefault(current.locales.get(0))
            return base
        }
        val locale = Locale(lang)
        Locale.setDefault(locale)
        val config = Configuration(current)
        config.setLocale(locale)
        return base.createConfigurationContext(config)
    }
}
