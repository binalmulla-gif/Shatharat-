package com.example.quotes

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

object BackupHelper {

    fun exportTo(ctx: Context, uri: Uri): Boolean {
        return try {
            val arr = JSONArray()
            for (q in QuoteStore.all(ctx)) {
                val o = JSONObject()
                o.put("text", q.text)
                o.put("author", q.author)
                o.put("source", q.source)
                o.put("note", q.note)
                o.put("created_at", q.createdAt)
                o.put("show_in_widget", q.showInWidget)
                arr.put(o)
            }
            val root = JSONObject()
            root.put("app", "quotes")
            root.put("version", 1)
            root.put("quotes", arr)
            val out = ctx.contentResolver.openOutputStream(uri) ?: return false
            out.use { it.write(root.toString(2).toByteArray(Charsets.UTF_8)) }
            true
        } catch (e: Exception) {
            false
        }
    }

    // Returns the number of quotes added, or -1 if the file could not be read
    fun importFrom(ctx: Context, uri: Uri): Int {
        return try {
            val input = ctx.contentResolver.openInputStream(uri) ?: return -1
            val raw = input.use { String(it.readBytes(), Charsets.UTF_8) }
            val root = JSONObject(raw)
            val arr = root.optJSONArray("quotes") ?: return -1
            var added = 0
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val text = o.optString("text").trim()
                if (text.isEmpty()) continue
                val created = o.optLong("created_at", 0L)
                val ok = QuoteStore.insertIfNew(
                    ctx,
                    text,
                    o.optString("author"),
                    o.optString("source"),
                    o.optString("note"),
                    if (created > 0L) created else System.currentTimeMillis(),
                    o.optBoolean("show_in_widget", true)
                )
                if (ok) added++
            }
            added
        } catch (e: Exception) {
            -1
        }
    }
}
