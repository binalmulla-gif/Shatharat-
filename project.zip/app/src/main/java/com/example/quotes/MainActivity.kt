package com.example.quotes

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var listView: ListView
    private lateinit var countView: TextView
    private var quotes: List<Quote> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listView = findViewById(R.id.list)
        countView = findViewById(R.id.count)
        listView.emptyView = findViewById(R.id.empty)

        findViewById<TextView>(R.id.add_button).setOnClickListener {
            startActivity(Intent(this, EditQuoteActivity::class.java))
        }
        listView.setOnItemClickListener { _, _, position, _ ->
            val i = Intent(this, EditQuoteActivity::class.java)
            i.putExtra(EditQuoteActivity.EXTRA_ID, quotes[position].id)
            startActivity(i)
        }
        listView.setOnItemLongClickListener { _, _, position, _ ->
            confirmDelete(quotes[position])
            true
        }
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        quotes = QuoteStore.all(this)
        countView.text = getString(R.string.count_fmt, quotes.size)
        listView.adapter = QuoteAdapter()
    }

    private fun confirmDelete(q: Quote) {
        AlertDialog.Builder(this)
            .setMessage(R.string.delete_confirm)
            .setPositiveButton(R.string.delete) { _, _ ->
                QuoteStore.delete(this, q.id)
                QuoteWidgetProvider.refreshAll(this)
                reload()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private inner class QuoteAdapter : BaseAdapter() {
        override fun getCount(): Int = quotes.size

        override fun getItem(position: Int): Any = quotes[position]

        override fun getItemId(position: Int): Long = quotes[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_quote, parent, false)
            val q = quotes[position]
            v.findViewById<TextView>(R.id.q_text).text = q.text

            val meta = SpannableStringBuilder()
            if (q.author.isNotEmpty()) {
                meta.append(q.author)
                meta.setSpan(
                    StyleSpan(Typeface.BOLD),
                    0,
                    meta.length,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
            if (q.source.isNotEmpty()) {
                if (meta.isNotEmpty()) meta.append(" — ")
                meta.append(q.source)
            }
            val metaView = v.findViewById<TextView>(R.id.q_meta)
            metaView.visibility = if (meta.isEmpty()) View.GONE else View.VISIBLE
            metaView.text = meta
            return v
        }
    }
}
