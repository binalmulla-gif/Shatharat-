package com.example.quotes

import android.content.Context
import android.widget.ArrayAdapter
import android.widget.Filter

object TextUtil {
    // Normalizes text for matching only: ignores Arabic diacritics, tatweel, alef forms and case
    fun normalize(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            when (ch) {
                in '\u064B'..'\u065F', '\u0670', '\u0640' -> {
                }
                'أ', 'إ', 'آ', 'ٱ' -> sb.append('ا')
                'ى' -> sb.append('ي')
                else -> sb.append(ch)
            }
        }
        return sb.toString().trim()
    }
}

class SuggestAdapter(context: Context, private val names: List<String>) :
    ArrayAdapter<String>(context, android.R.layout.simple_dropdown_item_1line, ArrayList<String>()) {

    private val suggestFilter = object : Filter() {
        override fun performFiltering(constraint: CharSequence?): FilterResults {
            val typed = constraint?.toString() ?: ""
            val q = TextUtil.normalize(typed)
            val matches: List<String> = if (q.isEmpty()) {
                emptyList<String>()
            } else {
                names.filter { it != typed && TextUtil.normalize(it).contains(q) }
            }
            val r = FilterResults()
            r.values = matches
            r.count = matches.size
            return r
        }

        @Suppress("UNCHECKED_CAST")
        override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
            clear()
            val values = results?.values as? List<String>
            if (values != null) addAll(values)
            notifyDataSetChanged()
        }
    }

    override fun getFilter(): Filter = suggestFilter
}
