package com.example.quotes

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray

data class Quote(
    val id: Long,
    val text: String,
    val author: String,
    val source: String,
    val note: String,
    val createdAt: Long,
    val showInWidget: Boolean
)

internal class QuoteDb(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "quotes.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE quotes (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "text TEXT NOT NULL, " +
                "author TEXT NOT NULL DEFAULT '', " +
                "source TEXT NOT NULL DEFAULT '', " +
                "note TEXT NOT NULL DEFAULT '', " +
                "created_at INTEGER NOT NULL, " +
                "show_in_widget INTEGER NOT NULL DEFAULT 1)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
    }
}

object QuoteStore {
    private const val PREFS = "quotes_prefs"
    private const val KEY_OLD_QUOTES = "quotes"
    private const val KEY_MIGRATED = "migrated_to_db"
    private const val KEY_LAST_AUTHOR = "last_author"
    private const val KEY_LAST_SOURCE = "last_source"

    private val COLUMNS = arrayOf(
        "id", "text", "author", "source", "note", "created_at", "show_in_widget"
    )

    @Volatile
    private var helper: QuoteDb? = null

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun db(ctx: Context): SQLiteDatabase {
        val h = helper ?: synchronized(this) {
            helper ?: QuoteDb(ctx).also { helper = it }
        }
        val d = h.writableDatabase
        migrateIfNeeded(ctx, d)
        return d
    }

    // Moves quotes saved by earlier versions (stored as JSON) into the database, once.
    @Synchronized
    private fun migrateIfNeeded(ctx: Context, d: SQLiteDatabase) {
        val p = prefs(ctx)
        if (p.getBoolean(KEY_MIGRATED, false)) return
        val raw = p.getString(KEY_OLD_QUOTES, null)
        var ok = true
        if (raw != null) {
            ok = false
            try {
                val arr = JSONArray(raw)
                d.beginTransaction()
                try {
                    // the old list was stored newest-first; insert the oldest first
                    for (i in arr.length() - 1 downTo 0) {
                        val o = arr.optJSONObject(i) ?: continue
                        val oldId = o.optLong("id", 0L)
                        val cv = ContentValues()
                        cv.put("text", o.optString("text"))
                        cv.put("author", o.optString("author"))
                        cv.put("source", o.optString("source"))
                        cv.put("note", "")
                        cv.put("created_at", if (oldId > 0L) oldId else System.currentTimeMillis())
                        cv.put("show_in_widget", 1)
                        d.insert("quotes", null, cv)
                    }
                    d.setTransactionSuccessful()
                    ok = true
                } finally {
                    d.endTransaction()
                }
            } catch (e: Exception) {
                ok = false
            }
        }
        if (ok) {
            p.edit().putBoolean(KEY_MIGRATED, true).remove(KEY_OLD_QUOTES).apply()
        }
    }

    private fun fromCursor(c: Cursor): Quote = Quote(
        id = c.getLong(0),
        text = c.getString(1) ?: "",
        author = c.getString(2) ?: "",
        source = c.getString(3) ?: "",
        note = c.getString(4) ?: "",
        createdAt = c.getLong(5),
        showInWidget = c.getInt(6) == 1
    )

    fun all(ctx: Context): List<Quote> {
        val list = ArrayList<Quote>()
        db(ctx).query(
            "quotes", COLUMNS, null, null, null, null, "created_at DESC, id DESC"
        ).use { c ->
            while (c.moveToNext()) list.add(fromCursor(c))
        }
        return list
    }

    fun get(ctx: Context, id: Long): Quote? {
        return db(ctx).query(
            "quotes", COLUMNS, "id = ?", arrayOf(id.toString()), null, null, null
        ).use { c ->
            if (c.moveToFirst()) fromCursor(c) else null
        }
    }

    fun count(ctx: Context): Long = DatabaseUtils.queryNumEntries(db(ctx), "quotes")

    fun add(
        ctx: Context,
        text: String,
        author: String,
        source: String,
        note: String = "",
        showInWidget: Boolean = true
    ) {
        val cv = ContentValues()
        cv.put("text", text)
        cv.put("author", author)
        cv.put("source", source)
        cv.put("note", note)
        cv.put("created_at", System.currentTimeMillis())
        cv.put("show_in_widget", if (showInWidget) 1 else 0)
        db(ctx).insert("quotes", null, cv)
        prefs(ctx).edit()
            .putString(KEY_LAST_AUTHOR, author)
            .putString(KEY_LAST_SOURCE, source)
            .apply()
    }

    fun update(
        ctx: Context,
        id: Long,
        text: String,
        author: String,
        source: String,
        note: String,
        showInWidget: Boolean
    ) {
        val cv = ContentValues()
        cv.put("text", text)
        cv.put("author", author)
        cv.put("source", source)
        cv.put("note", note)
        cv.put("show_in_widget", if (showInWidget) 1 else 0)
        db(ctx).update("quotes", cv, "id = ?", arrayOf(id.toString()))
    }

    fun delete(ctx: Context, id: Long) {
        db(ctx).delete("quotes", "id = ?", arrayOf(id.toString()))
    }

    // A random quote that is allowed in the widget, preferably different from the current one
    fun randomForWidget(ctx: Context, excludeId: Long): Quote? {
        val d = db(ctx)
        if (excludeId != -1L) {
            val other = d.query(
                "quotes", COLUMNS, "show_in_widget = 1 AND id != ?",
                arrayOf(excludeId.toString()), null, null, "RANDOM()", "1"
            ).use { c ->
                if (c.moveToFirst()) fromCursor(c) else null
            }
            if (other != null) return other
        }
        return d.query(
            "quotes", COLUMNS, "show_in_widget = 1", null, null, null, "RANDOM()", "1"
        ).use { c ->
            if (c.moveToFirst()) fromCursor(c) else null
        }
    }

    fun authors(ctx: Context): List<String> = distinctValues(ctx, "author")

    fun sources(ctx: Context): List<String> = distinctValues(ctx, "source")

    private fun distinctValues(ctx: Context, column: String): List<String> {
        val list = ArrayList<String>()
        db(ctx).rawQuery(
            "SELECT DISTINCT $column FROM quotes WHERE $column != '' ORDER BY $column", null
        ).use { c ->
            while (c.moveToNext()) list.add(c.getString(0))
        }
        return list
    }

    fun lastAuthor(ctx: Context): String = prefs(ctx).getString(KEY_LAST_AUTHOR, "") ?: ""

    fun lastSource(ctx: Context): String = prefs(ctx).getString(KEY_LAST_SOURCE, "") ?: ""
}
