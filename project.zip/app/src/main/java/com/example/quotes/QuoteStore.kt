package com.example.quotes

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Quote(
    val id: Long,
    val text: String,
    val author: String,
    val source: String
)

object QuoteStore {
    private const val PREFS = "quotes_prefs"
    private const val KEY_QUOTES = "quotes"
    private const val KEY_LAST_AUTHOR = "last_author"
    private const val KEY_LAST_SOURCE = "last_source"

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun all(ctx: Context): List<Quote> {
        val raw = prefs(ctx).getString(KEY_QUOTES, "[]") ?: "[]"
        val arr = try {
            JSONArray(raw)
        } catch (e: Exception) {
            JSONArray()
        }
        val list = ArrayList<Quote>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            list.add(
                Quote(
                    o.optLong("id"),
                    o.optString("text"),
                    o.optString("author"),
                    o.optString("source")
                )
            )
        }
        return list
    }

    private fun saveAll(ctx: Context, list: List<Quote>) {
        val arr = JSONArray()
        for (q in list) {
            val o = JSONObject()
            o.put("id", q.id)
            o.put("text", q.text)
            o.put("author", q.author)
            o.put("source", q.source)
            arr.put(o)
        }
        prefs(ctx).edit().putString(KEY_QUOTES, arr.toString()).apply()
    }

    fun add(ctx: Context, text: String, author: String, source: String) {
        val list = ArrayList(all(ctx))
        list.add(0, Quote(System.currentTimeMillis(), text, author, source))
        saveAll(ctx, list)
        prefs(ctx).edit()
            .putString(KEY_LAST_AUTHOR, author)
            .putString(KEY_LAST_SOURCE, source)
            .apply()
    }

    fun delete(ctx: Context, id: Long) {
        saveAll(ctx, all(ctx).filter { it.id != id })
    }

    fun random(ctx: Context): Quote? = all(ctx).randomOrNull()

    fun lastAuthor(ctx: Context): String = prefs(ctx).getString(KEY_LAST_AUTHOR, "") ?: ""

    fun lastSource(ctx: Context): String = prefs(ctx).getString(KEY_LAST_SOURCE, "") ?: ""
}
