package com.example.quotes

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class EditQuoteActivity : Activity() {

    private var quoteId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        val titleView = findViewById<TextView>(R.id.e_title)
        val textField = findViewById<EditText>(R.id.e_text)
        val authorField = findViewById<EditText>(R.id.e_author)
        val sourceField = findViewById<EditText>(R.id.e_source)
        val saveButton = findViewById<Button>(R.id.e_save)
        val cancelButton = findViewById<Button>(R.id.e_cancel)
        val deleteButton = findViewById<Button>(R.id.e_delete)

        quoteId = intent.getLongExtra(EXTRA_ID, -1L)
        if (quoteId != -1L) {
            val q = QuoteStore.all(this).firstOrNull { it.id == quoteId }
            if (q == null) {
                finish()
                return
            }
            titleView.setText(R.string.edit_quote)
            textField.setText(q.text)
            authorField.setText(q.author)
            sourceField.setText(q.source)
            deleteButton.visibility = View.VISIBLE
        } else {
            titleView.setText(R.string.new_quote)
            authorField.setText(QuoteStore.lastAuthor(this))
            sourceField.setText(QuoteStore.lastSource(this))
        }

        saveButton.setOnClickListener {
            val text = textField.text.toString().trim()
            if (text.isEmpty()) {
                Toast.makeText(this, R.string.text_required, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val author = authorField.text.toString().trim()
            val source = sourceField.text.toString().trim()
            if (quoteId == -1L) {
                QuoteStore.add(this, text, author, source)
            } else {
                QuoteStore.update(this, quoteId, text, author, source)
            }
            QuoteWidgetProvider.refreshAll(this)
            Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show()
            finish()
        }

        cancelButton.setOnClickListener { finish() }

        deleteButton.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage(R.string.delete_confirm)
                .setPositiveButton(R.string.delete) { _, _ ->
                    QuoteStore.delete(this, quoteId)
                    QuoteWidgetProvider.refreshAll(this)
                    finish()
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }

    companion object {
        const val EXTRA_ID = "quote_id"
    }
}
