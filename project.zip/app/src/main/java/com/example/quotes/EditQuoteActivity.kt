package com.example.quotes

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.DateFormat
import java.util.Date

class EditQuoteActivity : Activity() {

    private var quoteId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        val titleView = findViewById<TextView>(R.id.e_title)
        val pasteButton = findViewById<TextView>(R.id.e_paste)
        val textField = findViewById<EditText>(R.id.e_text)
        val authorField = findViewById<AutoCompleteTextView>(R.id.e_author)
        val sourceField = findViewById<AutoCompleteTextView>(R.id.e_source)
        val noteField = findViewById<EditText>(R.id.e_note)
        val widgetSwitch = findViewById<Switch>(R.id.e_widget)
        val dateView = findViewById<TextView>(R.id.e_date)
        val saveButton = findViewById<Button>(R.id.e_save)
        val cancelButton = findViewById<Button>(R.id.e_cancel)
        val deleteButton = findViewById<Button>(R.id.e_delete)

        // suggestions from names entered before
        authorField.setAdapter(SuggestAdapter(this, QuoteStore.authors(this)))
        sourceField.setAdapter(SuggestAdapter(this, QuoteStore.sources(this)))

        quoteId = intent.getLongExtra(EXTRA_ID, -1L)
        if (quoteId != -1L) {
            val q = QuoteStore.get(this, quoteId)
            if (q == null) {
                finish()
                return
            }
            titleView.setText(R.string.edit_quote)
            textField.setText(q.text)
            authorField.setText(q.author, false)
            sourceField.setText(q.source, false)
            noteField.setText(q.note)
            widgetSwitch.isChecked = q.showInWidget
            dateView.text = getString(
                R.string.saved_on_fmt,
                DateFormat.getDateInstance(DateFormat.LONG).format(Date(q.createdAt))
            )
            dateView.visibility = View.VISIBLE
            deleteButton.visibility = View.VISIBLE
        } else {
            titleView.setText(R.string.new_quote)
            pasteButton.visibility = View.VISIBLE
            authorField.setText(QuoteStore.lastAuthor(this), false)
            sourceField.setText(QuoteStore.lastSource(this), false)
            widgetSwitch.isChecked = true
        }

        pasteButton.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            val pasted = if (clip != null && clip.itemCount > 0) {
                clip.getItemAt(0).coerceToText(this).toString().trim()
            } else {
                ""
            }
            if (pasted.isEmpty()) {
                Toast.makeText(this, R.string.clipboard_empty, Toast.LENGTH_SHORT).show()
            } else {
                textField.setText(pasted)
                textField.setSelection(pasted.length)
            }
        }

        saveButton.setOnClickListener {
            val text = textField.text.toString().trim()
            if (text.isEmpty()) {
                Toast.makeText(this, R.string.text_required, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val author = authorField.text.toString().trim()
            val source = sourceField.text.toString().trim()
            val note = noteField.text.toString().trim()
            val showInWidget = widgetSwitch.isChecked
            if (quoteId == -1L) {
                QuoteStore.add(this, text, author, source, note, showInWidget)
            } else {
                QuoteStore.update(this, quoteId, text, author, source, note, showInWidget)
            }
            QuoteWidgetProvider.refreshAll(this)
            Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show()
            finish()
        }

        cancelButton.setOnClickListener { finish() }

        deleteButton.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage(R.string.delete_confirm)
                .setPositiveButton(R.string.delete) { _, _ ->
                    QuoteStore.delete(this, quoteId)
                    QuoteWidgetProvider.refreshAll(this)
                    finish()
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }

    companion object {
        const val EXTRA_ID = "quote_id"
    }
}
