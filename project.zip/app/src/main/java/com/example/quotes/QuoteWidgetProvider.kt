package com.example.quotes

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.view.View
import android.widget.RemoteViews

class QuoteWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, buildViews(context, appWidgetManager, id))
        }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        appWidgetManager.updateAppWidget(
            appWidgetId,
            buildViews(context, appWidgetManager, appWidgetId)
        )
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            refreshAll(context)
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.example.quotes.REFRESH"

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, QuoteWidgetProvider::class.java)
            )
            for (id in ids) {
                manager.updateAppWidget(id, buildViews(context, manager, id))
            }
        }

        private fun buildMeta(q: Quote): CharSequence {
            val sb = SpannableStringBuilder()
            if (q.author.isNotEmpty()) {
                sb.append(q.author)
                sb.setSpan(
                    StyleSpan(Typeface.BOLD),
                    0,
                    sb.length,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
            if (q.source.isNotEmpty()) {
                if (sb.isNotEmpty()) sb.append(" — ")
                sb.append(q.source)
            }
            return sb
        }

        private fun buildViews(
            context: Context,
            manager: AppWidgetManager,
            widgetId: Int
        ): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_quote)

            // Fit the number of quote lines to the widget height so the author line is never cut off
            val options = manager.getAppWidgetOptions(widgetId)
            var heightDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
            if (heightDp <= 0) heightDp = 180
            val lines = ((heightDp - 60) / 24).coerceIn(2, 12)
            views.setInt(R.id.w_text, "setMaxLines", lines)

            val q = QuoteStore.random(context)
            if (q == null) {
                views.setTextViewText(R.id.w_text, context.getString(R.string.widget_empty))
                views.setViewVisibility(R.id.w_meta, View.GONE)
            } else {
                views.setTextViewText(R.id.w_text, q.text)
                val meta = buildMeta(q)
                if (meta.isEmpty()) {
                    views.setViewVisibility(R.id.w_meta, View.GONE)
                } else {
                    views.setViewVisibility(R.id.w_meta, View.VISIBLE)
                    views.setTextViewText(R.id.w_meta, meta)
                }
            }

            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

            val refreshIntent = Intent(context, QuoteWidgetProvider::class.java)
                .setAction(ACTION_REFRESH)
            views.setOnClickPendingIntent(
                R.id.w_refresh,
                PendingIntent.getBroadcast(context, 0, refreshIntent, flags)
            )

            val openIntent = Intent(context, MainActivity::class.java)
            views.setOnClickPendingIntent(
                R.id.w_root,
                PendingIntent.getActivity(context, 1, openIntent, flags)
            )
            return views
        }
    }
}
