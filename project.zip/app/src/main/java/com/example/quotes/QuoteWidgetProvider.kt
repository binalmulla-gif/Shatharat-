package com.example.quotes

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.view.View
import android.widget.RemoteViews

class QuoteWidgetProvider : AppWidgetProvider() {

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        WidgetUpdateWorker.schedule(context)
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        WidgetUpdateWorker.cancel(context)
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        WidgetUpdateWorker.schedule(context)
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, buildViews(context, appWidgetManager, id, false))
        }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        appWidgetManager.updateAppWidget(
            appWidgetId,
            buildViews(context, appWidgetManager, appWidgetId, false)
        )
    }

    companion object {
        private const val STATE = "widget_state"

        // forceNew = true picks a new random quote; false keeps the one currently shown
        fun refreshAll(context: Context, forceNew: Boolean = false) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, QuoteWidgetProvider::class.java)
            )
            for (id in ids) {
                manager.updateAppWidget(id, buildViews(context, manager, id, forceNew))
            }
        }

        private fun pickQuote(context: Context, widgetId: Int, forceNew: Boolean): Quote? {
            val sp = context.getSharedPreferences(STATE, Context.MODE_PRIVATE)
            val currentId = sp.getLong("w_$widgetId", -1L)
            var q: Quote? = null
            if (!forceNew && currentId != -1L) {
                val c = QuoteStore.get(context, currentId)
                if (c != null && c.showInWidget) q = c
            }
            if (q == null) q = QuoteStore.randomForWidget(context, currentId)
            sp.edit().putLong("w_$widgetId", q?.id ?: -1L).apply()
            return q
        }

        private fun buildMeta(q: Quote): CharSequence {
            val sb = SpannableStringBuilder()
            if (q.author.isNotEmpty()) {
                sb.append(q.author)
                sb.setSpan(
                    StyleSpan(Typeface.BOLD),
                    0,
                    sb.length,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
            if (q.source.isNotEmpty()) {
                if (sb.isNotEmpty()) sb.append(" — ")
                sb.append(q.source)
            }
            return sb
        }

        // Shared text: the quote in quotation marks, and only the author's name under it
        private fun buildShareText(q: Quote): String {
            val quote = "“" + q.text + "”"
            return if (q.author.isNotEmpty()) quote + "\n— " + q.author else quote
        }

        private fun buildViews(
            context: Context,
            manager: AppWidgetManager,
            widgetId: Int,
            forceNew: Boolean
        ): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_quote)

            // Fit the number of quote lines to the widget height so the author line is never cut off
            val options = manager.getAppWidgetOptions(widgetId)
            var heightDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
            if (heightDp <= 0) heightDp = 180
            val lines = ((heightDp - 60) / 24).coerceIn(2, 12)
            views.setInt(R.id.w_text, "setMaxLines", lines)

            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

            val q = pickQuote(context, widgetId, forceNew)
            if (q == null) {
                val message = if (QuoteStore.count(context) == 0L) {
                    R.string.widget_empty
                } else {
                    R.string.widget_none_visible
                }
                views.setTextViewText(R.id.w_text, context.getString(message))
                views.setViewVisibility(R.id.w_meta, View.GONE)
                views.setViewVisibility(R.id.w_share, View.GONE)
            } else {
                views.setTextViewText(R.id.w_text, q.text)
                val meta = buildMeta(q)
                if (meta.isEmpty()) {
                    views.setViewVisibility(R.id.w_meta, View.GONE)
                } else {
                    views.setViewVisibility(R.id.w_meta, View.VISIBLE)
                    views.setTextViewText(R.id.w_meta, meta)
                }

                val send = Intent(Intent.ACTION_SEND)
                send.type = "text/plain"
                send.putExtra(Intent.EXTRA_TEXT, buildShareText(q))
                val chooser = Intent.createChooser(send, null)
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                views.setViewVisibility(R.id.w_share, View.VISIBLE)
                views.setOnClickPendingIntent(
                    R.id.w_share,
                    PendingIntent.getActivity(context, 1000 + widgetId, chooser, flags)
                )
            }

            val openIntent = Intent(context, MainActivity::class.java)
            views.setOnClickPendingIntent(
                R.id.w_root,
                PendingIntent.getActivity(context, 1, openIntent, flags)
            )
            return views
        }
    }
}
